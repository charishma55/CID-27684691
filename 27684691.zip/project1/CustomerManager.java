package project1;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CustomerManager {

    public void registerCustomer(String name, String email, String phoneNumber, String address) {
        try (Connection conn = DBUtil.getConnection()) {
            String sql = "INSERT INTO Customer (name, email, phone_number, address) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, name);
                stmt.setString(2, email);
                stmt.setString(3, phoneNumber);
                stmt.setString(4, address);
                stmt.executeUpdate();
                System.out.println("Customer registered successfully.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewCustomerDetails(int customerId) {
        try (Connection conn = DBUtil.getConnection()) {
            String sql = "SELECT * FROM Customer WHERE customer_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, customerId);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        System.out.println("Customer ID: " + rs.getInt("customer_id"));
                        System.out.println("Name: " + rs.getString("name"));
                        System.out.println("Email: " + rs.getString("email"));
                        System.out.println("Phone Number: " + rs.getString("phone_number"));
                        System.out.println("Address: " + rs.getString("address"));
                    } else {
                        System.out.println("Customer not found.");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateCustomer(int customerId, String name, String email, String phoneNumber, String address) {
        try (Connection conn = DBUtil.getConnection()) {
            String sql = "UPDATE Customer SET name = ?, email = ?, phone_number = ?, address = ? WHERE customer_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, name);
                stmt.setString(2, email);
                stmt.setString(3, phoneNumber);
                stmt.setString(4, address);
                stmt.setInt(5, customerId);
                stmt.executeUpdate();
                System.out.println("Customer updated successfully.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteCustomer(int customerId) {
        try (Connection conn = DBUtil.getConnection()) {
            String sql = "DELETE FROM Customer WHERE customer_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, customerId);
                stmt.executeUpdate();
                System.out.println("Customer deleted successfully.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

