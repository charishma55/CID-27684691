package project1;

import java.util.Scanner;

public class BankingSystemApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        AccountManager accountManager = new AccountManager();
        TransactionManager transactionManager = new TransactionManager();
        CustomerManager customerManager = new CustomerManager();

        while (true) {
            System.out.println("\nBanking System Menu:");
            System.out.println("1. Account Management");
            System.out.println("2. Transaction Management");
            System.out.println("3. Customer Management");
            System.out.println("4. Exit");
            System.out.print("Select an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("\nAccount Management:");
                    System.out.println("1. Create a new account");
                    System.out.println("2. View account details");
                    System.out.println("3. Update account information");
                    System.out.println("4. Close an account");
                    System.out.print("Select an option: ");
                    int accountChoice = scanner.nextInt();
                    handleAccountManagement(accountManager, scanner, accountChoice);
                    break;

                case 2:
                    System.out.println("\nTransaction Management:");
                    System.out.println("1. Deposit funds");
                    System.out.println("2. Withdraw funds");
                    System.out.println("3. Transfer funds");
                    System.out.println("4. View transaction history");
                    System.out.print("Select an option: ");
                    int transactionChoice = scanner.nextInt();
                    handleTransactionManagement(transactionManager, scanner, transactionChoice);
                    break;

                case 3:
                    System.out.println("\nCustomer Management:");
                    System.out.println("1. Register a new customer");
                    System.out.println("2. View customer details");
                    System.out.println("3. Update customer information");
                    System.out.println("4. Delete a customer");
                    System.out.print("Select an option: ");
                    int customerChoice = scanner.nextInt();
                    handleCustomerManagement(customerManager, scanner, customerChoice);
                    break;

                case 4:
                    System.out.println("Exiting the application...");
                    scanner.close();
                    System.exit(0);

                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void handleAccountManagement(AccountManager accountManager, Scanner scanner, int choice) {
        switch (choice) {
            case 1:
                System.out.print("Enter customer ID: ");
                int customerId = scanner.nextInt();
                System.out.print("Enter initial balance: ");
                double balance = scanner.nextDouble();
                System.out.print("Enter account type (savings/checking): ");
                String type = scanner.next();
                accountManager.createAccount(customerId, balance, type);
                break;

            case 2:
                System.out.print("Enter account number: ");
                int accountNumber = scanner.nextInt();
                accountManager.viewAccountDetails(accountNumber);
                break;

            case 3:
                System.out.print("Enter account number: ");
                accountNumber = scanner.nextInt();
                System.out.print("Enter new balance: ");
                balance = scanner.nextDouble();
                System.out.print("Enter new account type (savings/checking): ");
                type = scanner.next();
                accountManager.updateAccount(accountNumber, balance, type);
                break;

            case 4:
                System.out.print("Enter account number: ");
                accountNumber = scanner.nextInt();
                accountManager.closeAccount(accountNumber);
                break;

            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

    private static void handleTransactionManagement(TransactionManager transactionManager, Scanner scanner, int choice) {
        switch (choice) {
            case 1:
                System.out.print("Enter account number: ");
                int accountNumber = scanner.nextInt();
                System.out.print("Enter amount to deposit: ");
                double amount = scanner.nextDouble();
                transactionManager.deposit(accountNumber, amount);
                break;

            case 2:
                System.out.print("Enter account number: ");
                accountNumber = scanner.nextInt();
                System.out.print("Enter amount to withdraw: ");
                amount = scanner.nextDouble();
                transactionManager.withdraw(accountNumber, amount);
                break;

            case 3:
                System.out.print("Enter source account number: ");
                int fromAccount = scanner.nextInt();
                System.out.print("Enter destination account number: ");
                int toAccount = scanner.nextInt();
                System.out.print("Enter amount to transfer: ");
                amount = scanner.nextDouble();
                transactionManager.transfer(fromAccount, toAccount, amount);
                break;

            case 4:
                System.out.print("Enter account number: ");
                accountNumber = scanner.nextInt();
                transactionManager.viewTransactionHistory(accountNumber);
                break;

            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

    private static void handleCustomerManagement(CustomerManager customerManager, Scanner scanner, int choice) {
        switch (choice) {
            case 1:
                System.out.print("Enter name: ");
                String name = scanner.next();
                System.out.print("Enter email: ");
                String email = scanner.next();
                System.out.print("Enter phone number: ");
                String phoneNumber = scanner.next();
                System.out.print("Enter address: ");
                String address = scanner.next();
                customerManager.registerCustomer(name, email, phoneNumber, address);
                break;

            case 2:
                System.out.print("Enter customer ID: ");
                int customerId = scanner.nextInt();
                customerManager.viewCustomerDetails(customerId);
                break;

            case 3:
                System.out.print("Enter customer ID: ");
                customerId = scanner.nextInt();
                System.out.print("Enter new name: ");
                name = scanner.next();
                System.out.print("Enter new email: ");
                email = scanner.next();
                System.out.print("Enter new phone number: ");
                phoneNumber = scanner.next();
                System.out.print("Enter new address: ");
                address = scanner.next();
                customerManager.updateCustomer(customerId, name, email, phoneNumber, address);
                break;

            case 4:
                System.out.print("Enter customer ID: ");
                customerId = scanner.nextInt();
                customerManager.deleteCustomer(customerId);
                break;

            default:
                System.out.println("Invalid option. Please try again.");
        }
    }
}

