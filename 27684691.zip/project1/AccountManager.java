package project1;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AccountManager {

    public void createAccount(int customerId, double balance, String type) {
        try (Connection conn = DBUtil.getConnection()) {
            String sql = "INSERT INTO Account (customer_id, balance, type) VALUES (?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, customerId);
                stmt.setDouble(2, balance);
                stmt.setString(3, type);
                stmt.executeUpdate();
                System.out.println("Account created successfully.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewAccountDetails(int accountNumber) {
        try (Connection conn = DBUtil.getConnection()) {
            String sql = "SELECT * FROM Account WHERE account_number = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, accountNumber);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        System.out.println("Account Number: " + rs.getInt("account_number"));
                        System.out.println("Customer ID: " + rs.getInt("customer_id"));
                        System.out.println("Balance: " + rs.getDouble("balance"));
                        System.out.println("Type: " + rs.getString("type"));
                    } else {
                        System.out.println("Account not found.");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateAccount(int accountNumber, double balance, String type) {
        try (Connection conn = DBUtil.getConnection()) {
            String sql = "UPDATE Account SET balance = ?, type = ? WHERE account_number = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setDouble(1, balance);
                stmt.setString(2, type);
                stmt.setInt(3, accountNumber);
                stmt.executeUpdate();
                System.out.println("Account updated successfully.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void closeAccount(int accountNumber) {
        try (Connection conn = DBUtil.getConnection()) {
            String sql = "DELETE FROM Account WHERE account_number = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, accountNumber);
                stmt.executeUpdate();
                System.out.println("Account closed successfully.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
