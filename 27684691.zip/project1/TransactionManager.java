package project1;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TransactionManager {

    public void deposit(int accountNumber, double amount) {
        updateBalance(accountNumber, amount);
        recordTransaction(accountNumber, "deposit", amount);
    }

    public void withdraw(int accountNumber, double amount) {
        updateBalance(accountNumber, -amount);
        recordTransaction(accountNumber, "withdrawal", amount);
    }

    public void transfer(int fromAccount, int toAccount, double amount) {
        updateBalance(fromAccount, -amount);
        updateBalance(toAccount, amount);
        recordTransaction(fromAccount, "transfer", amount);
        recordTransaction(toAccount, "transfer", amount);
    }

    private void updateBalance(int accountNumber, double amount) {
        try (Connection conn = DBUtil.getConnection()) {
            String sql = "UPDATE Account SET balance = balance + ? WHERE account_number = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setDouble(1, amount);
                stmt.setInt(2, accountNumber);
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void recordTransaction(int accountNumber, String type, double amount) {
        try (Connection conn = DBUtil.getConnection()) {
            String sql = "INSERT INTO Transaction (account_number, transaction_type, amount) VALUES (?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, accountNumber);
                stmt.setString(2, type);
                stmt.setDouble(3, amount);
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewTransactionHistory(int accountNumber) {
        try (Connection conn = DBUtil.getConnection()) {
            String sql = "SELECT * FROM Transaction WHERE account_number = ? ORDER BY transaction_date DESC";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, accountNumber);
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        System.out.println("Transaction ID: " + rs.getInt("transaction_id"));
                        System.out.println("Type: " + rs.getString("transaction_type"));
                        System.out.println("Amount: " + rs.getDouble("amount"));
                        System.out.println("Date: " + rs.getTimestamp("transaction_date"));
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
